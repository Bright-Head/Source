libbmp
======

A libary that can read .BMP files from disk
